package co.ohlora.firemanapp.models;

/**
 * Created by Administrator on 2016-07-28.
 */
public class Fireman {
    public String fireid;
    public String fireemail;

    public Fireman(){

    }
}
